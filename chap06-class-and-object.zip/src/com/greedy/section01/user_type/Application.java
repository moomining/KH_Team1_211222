package com.greedy.section01.user_type;

public class Application {

	public static void main(String[] args) {
		
		/* 지금까지는 자바에서 제공되는 자료들을 취급하는 자료형에 대해 학습했다. */
		/* 이제 조금 더 복잡한 자료를 취급할 수 있는 방법을 생각해보자
		 * 회원 정보를 관리하기 위해 회원의 여러 정보(아이디, 비밀번호, 이름, 나이, 성별, 취미)를 취급하여 
		 * 관리하려고 한다
		 * */
		String id = "user01";
		String pwd = "pass01";
		String name = "홍길동";
		int age = 20;
		char gender = '남';
		String[] hobby = {"축구", "볼링", "테니스"};
		
		System.out.println("id : " + id);
		System.out.println("pwd : " + pwd);
		System.out.println("name : " + name);
		System.out.println("age : " + age);
		System.out.println("gender : " + gender);
		System.out.print("hobby : ");
		for(int i = 0; i < hobby.length; i++) {
			System.out.print(hobby[i] + " ");
		}
		System.out.println();
		

		/* 이렇게 각각의 변수로 관리하게 되면 여러가지 단점이 있다.
		 * 1. 변수명을 다 관리해야 하는 어려움이 생긴다.
		 * 2. 모든 회원 정보를 인자로 메소드 호출 시 전달해야 하면 너무 많은 값들을 인자로 전달해야 해서 한 눈에 안들어온다.
		 * 3. 리턴은 1개의 값만 가능하기 때문에 회원 정보를 묶어서 리턴 값으로 사용할 수 없다.
		 * 
		 * => 그래서 서로 다른 자료형의 데이터를 사용자(개발자) 정의로 하나로 묶어서 새로운 타입을 정의할 수 있는 방법을 제공한다.
		 *    Member(회원 정보)라고 하는 새로운 타입을 정의해보자.
		 * */
		
		/* 사용자 정의 자료형 사용하기 */
		/* 1. 변수 선언 및 객체 생성 */
		/* 자료형 변수명 = new 클래스명(); <- 지금까지 사용한 이 구문은 객체(instance)를 생성하는 구문이다.
		 * 사용자 정의 자료형인 클래스를 이용하기 위해서는 new 연산자로 heap 할당을 해야한다.
		 * 객체를 생성하게 되면 클래스에 정의한 필드와 메소드대로 객체(instance)가 생성된다.
		 * 아이디, 비밀번호, 이름, 나이, 성별, 취미를 연속된 메모리 주소에서 사용하도록 heap에 공간을 만들었다.
		 * */
		Member member = new Member();
		
		/* 이렇게 객체를 생성하고 나면 서로 다른 자료형들을 하나의 member라는 이름으로 관리할 수 있도록 공간을 생성한 것이다.
		 * heap에 생성되기 때문에 jvm 기본값으로 초기화된다.
		 * */
		/* 필드에 접근하기 위해서는 레퍼런스명.필드명 으로 접근한다.
		 * '.'은 참조연산자라고 하는데, 레퍼런스 변수가 참조하고 있는 주소로 접근한다는 의미를 가진다.
		 * 각 공간을 필드명으로 접근한다. (배열은 인덱스로 접근, 객체는 필드명으로 접근)
		 * */
		
		System.out.println("member.id : " + member.id);
		System.out.println("member.pwd : " + member.pwd);
		System.out.println("member.name : " + member.name);
		System.out.println("member.age : " + member.age);
		System.out.println("member.gender : " + member.gender);
		System.out.println("member.hobby : " + member.hobby);
		
		/* 2. 필드에 접근해서 변수 사용하듯 사용할 수 있다. */
		member.id = "user01";
		member.pwd = "pass01";
		member.name = "홍길동";
		member.age = 20;
		member.gender = '남';
		member.hobby = new String[] {"축구", "볼링", "테니스"};
		
		/* 값이 변경 되었는지 다시 확인 */
		System.out.println("member.id : " + member.id);
		System.out.println("member.pwd : " + member.pwd);
		System.out.println("member.name : " + member.name);
		System.out.println("member.age : " + member.age);
		System.out.println("member.gender : " + member.gender);
		System.out.print("member.hobby : ");
		for(int i = 0; i < member.hobby.length; i++) {
			System.out.print(member.hobby[i] + " ");
		}
		
		
		
		
		
	}
	


}
