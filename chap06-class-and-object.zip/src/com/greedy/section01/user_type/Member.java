package com.greedy.section01.user_type;

public class Member {
	
	/* 지금까지는 클래스 내부에 메소드만 작성해 보았지만
	 * 클래스 내부에는 메소드를 작성하지 않고 바로 변수를 선언할 수 도 있다.
	 * 이것을 전역변수(필드 == 인스턴스변수 == 속성)라고 부른다.
	 * */
	String id;
	String pwd;
	String name;
	int age;
	char gender;
	String[] hobby;

}
