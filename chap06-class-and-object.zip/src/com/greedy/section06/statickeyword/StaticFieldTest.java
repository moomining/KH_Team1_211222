package com.greedy.section06.statickeyword;

public class StaticFieldTest {
	
	/* non-static 필드와 static 필드 선언 */
	private int nonStaticCount;
	private static int staticCount;
	
	public StaticFieldTest() {}
	
	/* 두 필드에 대한 값을 확인 */
	public int getNonStaticCount() {
		return this.nonStaticCount;
	}
	
	public int getStaticCount() {
		/* static 필드에 접근하기 위해서는 클래스명.필드명 으로 접근한다. */
		return StaticFieldTest.staticCount;
	}
	
	/* 두 필드 값을 1씩 증가시키기 위한 용도의 메소드 */
	public void increaseNonStaticCount() {
		this.nonStaticCount++;
	}
	
	public void increaseStaticCount() {
		StaticFieldTest.staticCount++;
	}
	
	
	
	
}
