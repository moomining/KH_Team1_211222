package com.greedy.section02.encapsulation.problem2;

public class Monster {
	
	//String name;
	//int hp;
	
	/* 버전이 변경되면서 몬스터의 이름이 아니라 종류에 해당하는 내용을 저장하도록 필드가 변경 되었다. */
	String kinds;
	int hp;
	
}
