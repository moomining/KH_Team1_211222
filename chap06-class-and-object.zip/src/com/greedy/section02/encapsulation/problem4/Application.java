package com.greedy.section02.encapsulation.problem4;

public class Application {

	public static void main(String[] args) {

		/* 여전히 필드에 직접 접근할 수 있는 문제가 있으므로
		 * 필드에 직접 접근을 제한하는 방식으로 Monster 클래스를 다시 작성한다. 
		 * */
		
		/* 접근제한자 private를 붙여서 필드에 직접 접근하면 compile error가 발생한다.
		 * 접근을 허용하지 않았기 때문에 직접 접근할 수 없다는 의미이다.
		 * 메소드를 통한 간접 접근을 강제화 한 것이다.
		 * */
		Monster monster1 = new Monster();
		//monster1.kinds = "프랑켄슈타인";
		//monster1.hp = 200;
		
		monster1.setKinds("프랑켄슈타인");
		monster1.setHp(200);
		
		System.out.println(monster1.getInfo());
		
		/* 선언한 필드대로 공간은 생성되어 있지만 직접 접근 못하고
		 * public으로 접근을 허용한 메소드만 이용할 수 있도록 해놓은 것이다
		 * 이것을 캡슐화(encapsulation)라고 부른다.
		 * => 캡슐화는 유지보수성 증가를 위해 필드의 직접 접근을 제한하고
		 * public 메소드를 이용해서 간접적으로 접근하여 사용할 수 있도록 만든 기술로
		 * 클래스 작성 시 특별한 목적이 아닌 이상 캡슐화가 기본 원칙으로 사용되고 있다.
		 * */

	}

}
