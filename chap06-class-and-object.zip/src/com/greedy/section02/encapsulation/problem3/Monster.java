package com.greedy.section02.encapsulation.problem3;

public class Monster {
	
	//String name;
	String kinds;
	int hp;
	
	/**
	 * <pre>
	 * 몬스터의 정보를 입력 받아서 몬스터의 이름에 해당하는 필드 값을 변경해주는 메소드
	 * </pre>
	 * @param name 몬스터의 이름 입력
	 * */
	public void setInfo(String info) {
		/* 수정 전 */
		//this.name = name;
		
		/* 수정 후 */
		this.kinds = info;
	}
	
	/**
	 * <pre>
	 * 몬스터의 체력 정보를 입력받아서 몬스터의 체력에 해당하는 필드 값을 변경해주는 메소드
	 * </pre>
	 * @param hp 몬스터의 체력 입력
	 * */
	public void setHp(int hp) {
		if(hp > 0) {
			this.hp = hp;
		} else {
			this.hp = 0;
		}
	}
	
	/**
	 * <pre>
	 * 몬스터의 정보를 입력 받아 모든 필드의 내용을 문자열로 되돌려주는 메소드
	 * @return 모든 필드의 정보를 문자열 합치기하여 반환
	 * */
	public String getInfo() {
		/* 수정 전 */
		//return "몬스터의 이름은 " + this.name + "이고, 체력은 " + this.hp + "입니다.";
		
		/* 수정 후 */
		return "몬스터의 이름은 " + this.kinds + "이고, 체력은 " + this.hp + "입니다.";
	}

	/* name -> kinds로 변경할 경우 setInfo, getInfo 메소드는 변경해주어야 하지만
	 * 사용자(클라이언트)의 호출 코드는 변경하지 않아도 된다.
	 * */
	
}






