package com.greedy.section02.encapsulation.problem3;

public class Application3 {

	public static void main(String[] args) {
		/* 앞에서 작성한 두가지 문제점을 해결해보자 */
		/* 필드에 직접 접근하지 않고 메소드를 이용하여 간접 접근하도록 하면
		 * 올바르지 않은 범위의 값으로 변경되는 것도 막을 수 있고
		 * 필드 값의 변경이 발생하더라도 사용자는 코드를 변경하지 않아도 된다.
		 * */
		Monster monster1 = new Monster();
		monster1.setInfo("드라큘라");
		monster1.setHp(100);
		
		Monster monster2 = new Monster();
		monster2.setInfo("프랑켄슈타인");
		monster2.setHp(200);
		
		Monster monster3 = new Monster();
		monster3.setInfo("미이라");
		monster3.setHp(300);
		
		System.out.println(monster1.getInfo());
		System.out.println(monster2.getInfo());
		System.out.println(monster3.getInfo());
		
		/* ----------------------------------------- */
		/* 하지만 여전히 필드에 직접 접근할 수 있다. */
		monster3.kinds = "두치";
		monster3.hp = -500;
		
		System.out.println("monster3 kinds : " + monster3.kinds);
		System.out.println("monster3 hp : " + monster3.hp);
		
		
	}

}
