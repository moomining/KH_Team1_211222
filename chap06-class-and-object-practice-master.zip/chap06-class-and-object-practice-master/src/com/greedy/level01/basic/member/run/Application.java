package com.greedy.level01.basic.member.run;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
